package com.joshbell.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object NotificationScheduler {

    /** Cancels any previously-scheduled period alarms and schedules new ones for [day], today. */
    fun scheduleForDay(context: Context, day: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val periods = ScheduleStore.getPeriodsForDay(context, day)

        periods.forEachIndexed { index, period ->
            val startMin = period.startMinutes()
            if (startMin < 0) return@forEachIndexed

            val triggerCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, startMin / 60)
                set(Calendar.MINUTE, startMin % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            // Skip periods that have already started/passed today.
            if (triggerCal.timeInMillis <= System.currentTimeMillis()) return@forEachIndexed

            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("subject", period.subject)
                putExtra("room", period.room)
                putExtra("start", period.start)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, requestCodeFor(index), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerCal.timeInMillis,
                    pendingIntent
                )
            } catch (e: SecurityException) {
                // Exact alarm permission not granted on this OS version/device; silently skip.
            }
        }
    }

    /** Cancels alarms for up to [maxPeriods] request codes (call before rescheduling if desired). */
    fun cancelAll(context: Context, maxPeriods: Int = 8) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until maxPeriods) {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context, requestCodeFor(i), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }

    private fun requestCodeFor(periodIndex: Int) = 1000 + periodIndex
}
