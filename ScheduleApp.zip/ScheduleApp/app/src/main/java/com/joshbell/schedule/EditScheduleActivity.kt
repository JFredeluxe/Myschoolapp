package com.joshbell.schedule

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class EditScheduleActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_schedule)

        val editText = findViewById<EditText>(R.id.scheduleJsonEdit)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val resetButton = findViewById<Button>(R.id.resetButton)

        editText.setText(prettyPrint(ScheduleStore.getScheduleJson(this)))

        saveButton.setOnClickListener {
            val text = editText.text.toString()
            try {
                // Validate it's well-formed JSON before saving.
                JSONObject(text)
                ScheduleStore.saveScheduleJson(this, text)
                ScheduleWidgetProvider.updateAllWidgets(this)
                ScheduleStore.getSelectedDay(this)?.let { day ->
                    NotificationScheduler.scheduleForDay(this, day)
                }
                Toast.makeText(this, "Schedule saved", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this, "That's not valid JSON: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        resetButton.setOnClickListener {
            editText.setText(prettyPrint(ScheduleStore.defaultScheduleJson()))
        }
    }

    private fun prettyPrint(json: String): String {
        return try {
            JSONObject(json).toString(2)
        } catch (e: Exception) {
            json
        }
    }
}
