package com.joshbell.schedule

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

class ScheduleWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_schedule)

        val day = ScheduleStore.getSelectedDay(context)
        if (day == null || !ScheduleStore.isSelectionCurrent(context)) {
            views.setTextViewText(R.id.widgetDay, "Open the app")
            views.setTextViewText(R.id.widgetStatus, "Tap to set today's day")
        } else {
            views.setTextViewText(R.id.widgetDay, day)
            val periods = ScheduleStore.getPeriodsForDay(context, day)
            val nowMin = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

            val current = periods.firstOrNull { nowMin in it.startMinutes()..it.endMinutes() }
            val next = periods.firstOrNull { it.startMinutes() > nowMin }

            views.setTextViewText(
                R.id.widgetStatus,
                when {
                    current != null -> "Now: ${current.subject} (${current.room})\nuntil ${current.end}"
                    next != null -> "Next: ${next.subject} (${next.room})\nat ${next.start}"
                    else -> "No more classes today"
                }
            )
        }

        val launchIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ScheduleWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(context, ScheduleWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}
