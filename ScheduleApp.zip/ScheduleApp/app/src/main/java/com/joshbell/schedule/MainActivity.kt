package com.joshbell.schedule

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dayLabel: TextView
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dayLabel = findViewById(R.id.dayLabel)
        listView = findViewById(R.id.periodList)

        requestNotificationPermissionIfNeeded()

        if (!ScheduleStore.isSelectionCurrent(this)) {
            askWhatDayIsIt()
        } else {
            renderDay(ScheduleStore.getSelectedDay(this)!!)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_change_day -> {
                askWhatDayIsIt()
                true
            }
            R.id.action_edit_schedule -> {
                startActivity(Intent(this, EditScheduleActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun askWhatDayIsIt() {
        AlertDialog.Builder(this)
            .setTitle("What day is it?")
            .setItems(ScheduleStore.DAYS.toTypedArray()) { _, which ->
                val day = ScheduleStore.DAYS[which]
                ScheduleStore.setSelectedDay(this, day)
                renderDay(day)
                // Refresh widget + notifications for the new day.
                ScheduleWidgetProvider.updateAllWidgets(this)
                NotificationScheduler.scheduleForDay(this, day)
            }
            .setCancelable(false)
            .show()
    }

    private fun renderDay(day: String) {
        dayLabel.text = "Today: $day"
        val periods = ScheduleStore.getPeriodsForDay(this, day)
        val rows = periods.map { "${it.period}  ${it.subject}\n${it.room} — ${it.teacher}\n${it.start} - ${it.end}" }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }
    }
}
