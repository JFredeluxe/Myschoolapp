package com.joshbell.schedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class ClassPeriod(
    val period: String,
    val subject: String,
    val room: String,
    val teacher: String,
    val start: String, // "8:30 AM"
    val end: String    // "9:30 AM"
) {
    fun startMinutes(): Int = toMinutes(start)
    fun endMinutes(): Int = toMinutes(end)

    private fun toMinutes(t: String): Int {
        return try {
            val sdf = SimpleDateFormat("h:mm a", Locale.US)
            val cal = Calendar.getInstance()
            cal.time = sdf.parse(t) ?: return -1
            cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        } catch (e: Exception) {
            -1
        }
    }
}

object ScheduleStore {
    private const val PREFS = "schedule_prefs"
    private const val KEY_JSON = "schedule_json"
    private const val KEY_SELECTED_DAY = "selected_day"
    private const val KEY_SELECTED_DATE = "selected_date" // yyyy-MM-dd this was chosen for

    val DAYS = listOf("D1", "D2", "D3", "D4", "D5", "D6")

    // Best-effort transcription of the Lexington HS printed schedule for Bell, Joshua (Q1 2026-2027).
    // Some cells in the original printout were hard to read (letter codes / lunch waves) —
    // open "Edit Schedule" in the app to correct anything that's wrong.
    fun defaultScheduleJson(): String {
        val obj = JSONObject()

        fun period(period: String, subject: String, room: String, teacher: String, start: String, end: String) =
            JSONObject().apply {
                put("period", period)
                put("subject", subject)
                put("room", room)
                put("teacher", teacher)
                put("start", start)
                put("end", end)
            }

        fun arr(vararg items: JSONObject): JSONArray {
            val a = JSONArray()
            items.forEach { a.put(it) }
            return a
        }

        obj.put(
            "D1", arr(
                period("1", "Symphonic Band", "Rm 131", "Forman, Toby / Aramati, Justin", "8:30 AM", "9:30 AM"),
                period("2", "World History I", "Rm 178", "Weintraub, Jonathon / Goodstone, Jessica", "9:35 AM", "10:35 AM"),
                period("3B", "Lit and Comp I", "Rm 177", "Sarkis, Lucciana / Grant, Kristen", "11:10 AM", "12:10 PM"),
                period("4B", "Math 2: Geometry & Prob", "Rm 808", "Kuokkanen, Sonja", "12:15 PM", "1:10 PM"),
                period("5", "Spanish II", "Rm 611", "Perillo, Sophia", "1:15 PM", "2:10 PM"),
                period("6", "CPR/AED/First Aid Cert", "Rm FIT", "Kingman, Abbey", "2:15 PM", "3:10 PM")
            )
        )
        obj.put(
            "D2", arr(
                period("1", "Spanish II", "Rm 611", "Perillo, Sophia", "8:30 AM", "9:30 AM"),
                period("2", "Study", "Rm 414", "Olaharski, Lisa", "9:40 AM", "10:45 AM"),
                period("3B", "Study", "Rm 184", "Sarkis, Lucciana", "11:20 AM", "12:25 PM"),
                period("4B", "Environmental Science", "Rm 330", "King, Joshua", "12:30 PM", "1:35 PM"),
                period("5", "Homeroom/Advisory", "Rm 233", "Borden, James / LeComte, Rachel", "1:40 PM", "2:00 PM"),
                period("6", "Math 2: Geometry & Prob", "Rm 808", "Kuokkanen, Sonja", "2:05 PM", "3:10 PM")
            )
        )
        obj.put(
            "D3", arr(
                period("1", "World History I", "Rm 178", "Weintraub, Jonathon / Goodstone, Jessica", "8:30 AM", "9:30 AM"),
                period("2", "Symphonic Band", "Rm 131", "Forman, Toby / Aramati, Justin", "9:35 AM", "10:35 AM"),
                period("3B", "Study", "Rm 517", "Grant, Ashley", "11:10 AM", "12:10 PM"),
                period("4B", "Environmental Science", "Rm 330", "King, Joshua", "12:15 PM", "1:10 PM"),
                period("5", "I Block", "Iblock-000", "I Block Teacher", "1:15 PM", "2:05 PM"),
                period("6", "Lit and Comp I", "Rm 177", "Sarkis, Lucciana / Grant, Kristen", "2:10 PM", "3:10 PM")
            )
        )
        obj.put(
            "D4", arr(
                period("1", "Symphonic Band", "Rm 131", "Forman, Toby / Aramati, Justin", "8:30 AM", "9:30 AM"),
                period("2", "World History I", "Rm 178", "Weintraub, Jonathon / Goodstone, Jessica", "9:35 AM", "10:35 AM"),
                period("3B", "Lit and Comp I", "Rm 177", "Sarkis, Lucciana / Grant, Kristen", "11:10 AM", "12:10 PM"),
                period("4B", "Math 2: Geometry & Prob", "Rm 808", "Kuokkanen, Sonja", "12:15 PM", "1:10 PM"),
                period("5", "Spanish II", "Rm 611", "Perillo, Sophia", "1:15 PM", "2:10 PM"),
                period("6", "CPR/AED/First Aid Cert", "Rm FIT", "Kingman, Abbey", "2:10 PM", "3:10 PM")
            )
        )
        obj.put(
            "D5", arr(
                period("1", "Spanish II", "Rm 611", "Perillo, Sophia", "8:30 AM", "9:30 AM"),
                period("2", "Study", "Rm 518", "Dorfmann, Paola", "9:40 AM", "10:35 AM"),
                period("3B", "Lit and Comp I", "Rm 634", "Jayson, Rachel", "11:20 AM", "12:10 PM"),
                period("4B", "Environmental Science", "Rm 330", "King, Joshua", "12:15 PM", "1:25 PM"),
                period("5", "I Block", "Iblock-000", "I Block Teacher", "1:15 PM", "2:10 PM"),
                period("6", "Math 2: Geometry & Prob", "Rm 808", "Kuokkanen, Sonja", "2:05 PM", "3:10 PM")
            )
        )
        obj.put(
            "D6", arr(
                period("1", "World History I", "Rm 178", "Weintraub, Jonathon / Goodstone, Jessica", "8:30 AM", "9:30 AM"),
                period("2", "Symphonic Band", "Rm 131", "Forman, Toby / Aramati, Justin", "9:35 AM", "10:35 AM"),
                period("3B", "Study", "Rm 227", "Antoline, Jessica", "11:10 AM", "12:05 PM"),
                period("4B", "Environmental Science", "Rm 330", "King, Joshua", "12:10 PM", "1:10 PM"),
                period("5", "I Block", "Iblock-000", "I Block Teacher", "1:30 PM", "2:00 PM"),
                period("6", "Lit and Comp I", "Rm 177", "Sarkis, Lucciana / Grant, Kristen", "2:10 PM", "3:10 PM")
            )
        )

        return obj.toString()
    }

    fun getScheduleJson(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_JSON, null) ?: defaultScheduleJson().also {
            prefs.edit().putString(KEY_JSON, it).apply()
        }
    }

    fun saveScheduleJson(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_JSON, json).apply()
    }

    fun getPeriodsForDay(ctx: Context, day: String): List<ClassPeriod> {
        val json = JSONObject(getScheduleJson(ctx))
        if (!json.has(day)) return emptyList()
        val arr = json.getJSONArray(day)
        val list = mutableListOf<ClassPeriod>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                ClassPeriod(
                    o.getString("period"),
                    o.getString("subject"),
                    o.getString("room"),
                    o.getString("teacher"),
                    o.getString("start"),
                    o.getString("end")
                )
            )
        }
        return list
    }

    fun setSelectedDay(ctx: Context, day: String) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
        prefs.edit()
            .putString(KEY_SELECTED_DAY, day)
            .putString(KEY_SELECTED_DATE, today)
            .apply()
    }

    fun getSelectedDay(ctx: Context): String? {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SELECTED_DAY, null)
    }

    /** Returns true if the stored selected day is still valid for *today*. */
    fun isSelectionCurrent(ctx: Context): Boolean {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val storedDate = prefs.getString(KEY_SELECTED_DATE, null) ?: return false
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
        return storedDate == today
    }
}
