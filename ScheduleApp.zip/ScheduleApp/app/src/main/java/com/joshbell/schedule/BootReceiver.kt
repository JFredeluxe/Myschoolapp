package com.joshbell.schedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // If a day was already picked today, re-arm its notifications and refresh the widget.
            if (ScheduleStore.isSelectionCurrent(context)) {
                ScheduleStore.getSelectedDay(context)?.let { day ->
                    NotificationScheduler.scheduleForDay(context, day)
                }
            }
            ScheduleWidgetProvider.updateAllWidgets(context)
        }
    }
}
