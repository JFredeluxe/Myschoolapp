# My Schedule (Android)

A small Android app built from your Lexington HS Q1 2026-2027 schedule (D1–D6 rotation).

## What it does
- **First open each day**: pops up "What day is it?" with buttons D1–D6. Your pick is remembered for the rest of the day.
- **Main screen**: lists that day's periods — subject, room, teacher, time.
- **Home screen widget**: drop it on your home screen; it shows the current day and your current/next class, refreshing itself and whenever a class starts.
- **Notifications**: fires a notification at the start of each remaining period for the day you picked.
- **Edit schedule**: menu → "Edit schedule" opens the raw JSON so you can fix anything that was mis-read from the photo, or update it next quarter.

## Before you build
The schedule data was transcribed from a photo of your printed schedule — a few cells (letter/lunch codes, some times) were hard to read clearly. **Open the app once, go to Edit Schedule, and double-check the times/rooms against your real schedule before relying on the notifications.**

## How to get an APK — no software install (GitHub Actions)
1. Create a free account at github.com if you don't have one.
2. Create a new repository (any name, e.g. `schedule-app`).
3. Upload every file/folder from this `ScheduleApp` folder into that repo — either drag-and-drop on the GitHub website ("Add file" → "Upload files"), or if you know git:
   ```
   cd ScheduleApp
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/schedule-app.git
   git push -u origin main
   ```
4. Go to the **Actions** tab in your repo — a "Build APK" workflow will run automatically (takes 2-4 minutes).
5. When it finishes, click into the run → under **Artifacts**, download `ScheduleApp-debug-apk`. Unzip it to get `app-debug.apk`.
6. Transfer that `.apk` to your phone (email it to yourself, Google Drive, USB, etc.) and open it to install. You'll need to allow "install from unknown sources" the first time — Android will prompt you for this.
7. To add the widget: long-press your home screen → Widgets → "My Schedule" → drag it on.

## How to build it in Android Studio instead
1. Install **Android Studio** (free, from developer.android.com).
2. Open Android Studio → "Open" → select this `ScheduleApp` folder.
3. Let it sync (it will download the Gradle wrapper and dependencies automatically — first sync needs internet).
4. Plug in your Android phone (with USB debugging on) or start an emulator.
5. Click ▶ Run — or Build → Build Bundle(s)/APK(s) → Build APK(s) to just get the file.
6. To add the widget: long-press your home screen → Widgets → "My Schedule" → drag it on.

## Notes / limitations
- Android restricts home-screen widgets to updating at most every ~30 minutes automatically; the app also nudges it to refresh right when a class starts, so it stays accurate.
- Exact alarms need the "Alarms & reminders" permission on some phones (Settings → Apps → My Schedule → Alarms & reminders) — Android will usually prompt for this.
- Notifications are only scheduled for the day you pick each morning — reopen the app (or just answer the day prompt) each school day.
- minSdk is 26 (Android 8.0+), which covers essentially all phones in use today.

## Project structure
- `MainActivity.kt` — day picker + schedule list
- `EditScheduleActivity.kt` — JSON editor for the schedule data
- `ScheduleData.kt` — schedule model + storage (SharedPreferences)
- `ScheduleWidgetProvider.kt` — home screen widget
- `NotificationScheduler.kt` / `AlarmReceiver.kt` — per-period notifications
- `BootReceiver.kt` — re-arms today's notifications after a phone restart
